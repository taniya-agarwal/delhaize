import React, { Component } from "react";
import "./App.css";
const axios = require("axios");

class App extends Component {
  constructor() {
    super();
    this.state = {
      tableData: [],
      filterData: [],
      pg: 0
    };
  }

  componentDidMount() {
    axios.get("http://jsonplaceholder.typicode.com/posts").then(response => {
      // console.log(response);
      this.setState({ tableData: response.data });
      this.Next();
    });
   
  }

  Next() {
    this.setState({ pg: this.state.pg + 1 });
    let temp = [];
    for (let i = 0; i <  ((this.state.pg)*10); i++) {
      temp.push(this.state.tableData[i]);
    }
    this.setState({ filterData: temp });
  }

  render() {
    return (
      <div className="container">
        <h1>List of posts</h1>
        <div>
          <span>Filter data as per title: </span>
          <span>
            <input type="text" />
          </span>
        </div>
        <div className="table-section">
          <table>
            <tr>
              <th>no</th>
              <th>User Id</th>
              <th>Title</th>
              <th>Description</th>
            </tr>
            {this.state.filterData.map((item, index) => {
              return (
                <tr>
                  <td>{index + 1}</td>
                  <td>{item.userId}</td>
                  <td>{item.title}</td>
                  <td>{item.body}</td>
                </tr>
              );
            })}
          </table>
        </div>
        <button className='nextbtn' onClick={()=>this.Next()}>Next</button>
      </div>
    );
  }
}

export default App;
